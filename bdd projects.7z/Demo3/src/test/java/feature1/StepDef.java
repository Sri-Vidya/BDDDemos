package feature1;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
	static WebDriver driver;
	static PageFactoryForm factory=null;
	
	@Given("^user is on register page$")
	public void user_is_on_register_page() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.get("C:\\Users\\sriathot\\Desktop\\register.html");
		factory = new PageFactoryForm(driver);

	}
	@When("^user leaves name blank$")
	public void user_leaves_name_blank() throws Exception {
		factory.setName("");
		Thread.sleep(1000);
		factory.setButton();
		
	} 

	@Then("^display alert message$")
	public void display_alert_message() throws Exception {
		String msg=driver.switchTo().alert().getText();
		System.out.println(msg);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		
	}
	
	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
		
		factory.setName("sr");
		Thread.sleep(1000);
		factory.setButton();
		
	}
	
	@When("^user leaves email blank$")
	public void user_leaves_email_blank() throws Throwable {
		factory.setName("mahalakshmi");
		Thread.sleep(1000);
		factory.setEmail("");
		Thread.sleep(1000);
		factory.setButton();
	}
	
	@When("^user enters invalid email$")
	public void user_enters_invalid_email(DataTable arg1) throws Throwable {
		factory.setName("mahalakshmi");
		Thread.sleep(1000);
		
		List<String> list = arg1.asList(String.class);
		String data = null;
		for (String dataTemp : list) {
			data = dataTemp;
			factory.getEmail().clear();
			factory.setEmail(dataTemp);
			Thread.sleep(1000);
			factory.setButton();
			if (Pattern.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$", dataTemp)) {
				System.out.println("Matching ");
			} else {
				
				System.err.println("not matched ");

			}
		String msg=driver.switchTo().alert().getText();
		System.err.println(msg);
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
		}
		
	}
	@Then("^display alert message for email$")
	public void display_alert_message_for_email() throws Throwable {
	}
	
	@When("^user leaves mobile blank$")
	public void user_leaves_mobile_blank() throws Throwable {
		factory.setName("mahalakshmi");
		Thread.sleep(1000);
		factory.setEmail("srividya@gmail.com");
		Thread.sleep(1000);
		factory.setMobile("");
		Thread.sleep(1000);
		factory.setButton();
	}

/*@When("^user enters invalid mobile$")
public void user_enters_invalid_mobile(DataTable arg1) throws Throwable {
	factory.setName("mahalakshmi");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	List<String> list = arg1.asList(String.class);
	String data = null;
	for (String dataTemp : list) {
		data = dataTemp;
		factory.getMobile().clear();
		factory.setMobile(dataTemp);
		Thread.sleep(1000);
		factory.setButton();
		if (Pattern.matches("^[7-9]{1}[0-9]{9}$", dataTemp)) {
			System.out.println("Matching ");
		} else {
			
			System.err.println("not matched ");

		}
	String msg=driver.switchTo().alert().getText();
	System.err.println(msg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}
	
}*/


@When("^user enters invalid (\\d+)$")
public void user_enters_invalid(Integer arg1) throws Throwable {
	factory.setName("mahalakshmi");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	String mobile=arg1.toString();
	factory.setMobile(mobile);
	Thread.sleep(1000);
	factory.setButton();
	String msg=driver.switchTo().alert().getText();
	System.err.println(msg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
}



@Then("^display alert message for mobile$")
public void display_alert_message_for_mobile() throws Throwable {
}
	
@When("^user leaves address blank$")
public void user_leaves_address_blank() throws Throwable {
	factory.setName("mahalakshmi");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("9989530018");
	Thread.sleep(1000);
	factory.setAddress("");
	Thread.sleep(1000);
	factory.setButton();
}
@When("^user leaves gender blank$")
public void user_leaves_gender_blank() throws Throwable {
	factory.setName("mahalakshmi");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("9989530018");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setButton();
}

@When("^user leaves language blank$")
public void user_leaves_language_blank() throws Throwable {
	factory.setName("srividya");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("9989530018");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setGender2();
	Thread.sleep(1000);
	
}

@When("^user enters valid data$")
public void user_enters_valid_data() throws Throwable {
	factory.setName("srividya");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("9989530018");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setGender2();
	Thread.sleep(1000);
	factory.setButton();
}


@Then("^display success page$")
public void display_success_page() throws Throwable {
	
}


@After
	public void close() {
		driver.close();
	}

}
