package feature1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryForm {
	
	WebDriver wd;
	
	
	public PageFactoryForm(WebDriver webdriver) {
		this.wd=webdriver;
		PageFactory.initElements(wd, this);
		
	
	}
	public PageFactoryForm() {
		
	}
	
	@FindBy(id="txtName")
	@CacheLookup
	WebElement name;

	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(name="address")
	@CacheLookup
	WebElement address;
	
	@FindBy(id="male")
	@CacheLookup
	WebElement gender1;
	
	@FindBy(id="female")
	@CacheLookup
	WebElement gender2;
	
	@FindBy(name="language")
	@CacheLookup
	WebElement language;
	
	@FindBy(id="btnRegister")
	@CacheLookup
	WebElement button;
	
	public WebElement getGender1() {
		return gender1;
	}
	public void setGender1() {
		gender1.click();
	}
	public WebElement getGender2() {
		return gender2;
	}
	public void setGender2() {
		gender2.click();
	}
	public WebElement getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address.sendKeys(address);
	}
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language.click();
	}
	public WebElement getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}
	public WebElement getName() {
		return name;
	}
	public void setName(String name) {
		this.name.sendKeys(name);
	}
	public WebElement getButton() {
		return button;
	}
	public void setButton() {
		button.click();
	}

}
