package com.cg;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	static WebDriver driver;
	static PageFactoryBooking factory=null;
	
	@Given("^user is on booking page$")
	public void user_is_on_booking_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.get("file:///C:/Users/sriathot/Desktop/hotelbooking.html");
		factory = new PageFactoryBooking(driver);
	}

	@When("^user leaves first name blank$")
	public void user_leaves_first_name_blank() throws Throwable {
		factory.setFname("");
		Thread.sleep(1000);
		factory.setButton();
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
		String msg=driver.switchTo().alert().getText();
		System.out.println(msg);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		
	}
	@When("^user leaves last name blank$")
	public void user_leaves_last_name_blank() throws Throwable {
		factory.setFname("vidya");
		Thread.sleep(1000);
		factory.setLname("");
		Thread.sleep(1000);
		factory.setButton();
	}
	

@When("^user leaves email blank$")
public void user_leaves_email_blank() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("");
	Thread.sleep(1000);
	factory.setButton();
}

@When("^user enters invalid email$")
public void user_enters_invalid_email(DataTable arg1) throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	List<String> list = arg1.asList(String.class);
	String data = null;
	for (String dataTemp : list) {
		data = dataTemp;
		factory.getEmail().clear();
		factory.setEmail(dataTemp);
		Thread.sleep(1000);
		factory.setButton();
		if (Pattern.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$", dataTemp)) {
			System.out.println("Matching ");
		} else {
			
			System.err.println("not matched ");

		}
	String msg=driver.switchTo().alert().getText();
	System.err.println(msg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}
}

@Then("^display alert message for email$")
public void display_alert_message_for_email() throws Throwable {
}

@When("^user leaves mobile blank$")
public void user_leaves_mobile_blank() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("");
	Thread.sleep(1000);
	factory.setButton();
}

@When("^user enters invalid mobile$")
public void user_enters_invalid_mobile(DataTable arg1) throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	List<String> list = arg1.asList(String.class);
	String data=null;
	for (String dataTemp : list) {
		data = dataTemp;
		factory.getMobile().clear();
		factory.setMobile(dataTemp);
		Thread.sleep(1000);
		factory.setButton();
		if (Pattern.matches("^[7-9]{1}[0-9]{9}$", dataTemp)) {
			System.out.println("Matching ");
		} else {
			
			System.err.println("not matched ");

		}
	String msg=driver.switchTo().alert().getText();
	System.err.println(msg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}
}

@Then("^display alert message for mobile$")
public void display_alert_message_for_mobile() throws Throwable {
	
}


@When("^user leaves address blank$")
public void user_leaves_address_blank() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("");
	Thread.sleep(1000);
	factory.setButton();
	
}

@When("^user not select city$")
public void user_not_select_city() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Select City");
	Thread.sleep(1000);
	factory.setButton();
}

@When("^user not select state$")
public void user_not_select_state() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Hyderabad");
	Thread.sleep(1000);
	factory.setState("Select State");
	Thread.sleep(1000);
	factory.setButton();
}

@When("^user enters (\\d+)$")
public void user_enters(int noofpersons) throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Hyderabad");
	Thread.sleep(1000);
	factory.setState("Telangana");
	Thread.sleep(1000);
	factory.setPersons(noofpersons);
	Thread.sleep(1000);
	factory.setButton();
}

@Then("^allocate (\\d+) for (\\d+)$")
public void allocate_for(int guest, int rooms) throws Throwable {
	if (guest <= 3) {
		System.out.println("no of Rooms:" + rooms);
		assertEquals(1, rooms);
	} else if (guest <= 6) {
		System.out.println("no of Rooms:" + rooms);
		assertEquals(2, rooms);
	} else if (1 <= 9) {
		System.out.println("no of Rooms:" + rooms);
		assertEquals(3, rooms);
	}
}

@When("^user leaves card holder number blank$")
public void user_leaves_card_holder_number_blank() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Hyderabad");
	Thread.sleep(1000);
	factory.setState("Telangana");
	Thread.sleep(1000);
	factory.setCardname("");
	Thread.sleep(1000);
	factory.setButton();
}

@When("^user leaves debit card number blank$")
public void user_leaves_debit_card_number_blank() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Hyderabad");
	Thread.sleep(1000);
	factory.setState("Telangana");
	Thread.sleep(1000);
	factory.setCardname("srividya athota");
	Thread.sleep(1000);
	factory.setCardnumber("");
	Thread.sleep(1000);
	factory.setButton();
}
@When("^user leaves cvv blank$")
public void user_leaves_cvv_blank() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Hyderabad");
	Thread.sleep(1000);
	factory.setState("Telangana");
	Thread.sleep(1000);
	factory.setCardname("srividya athota");
	Thread.sleep(1000);
	factory.setCardnumber("123456789");
	Thread.sleep(1000);
	factory.setCvv("");
	Thread.sleep(1000);
	factory.setButton();
}
@When("^user leaves expiration month blank$")
public void user_leaves_expiration_month_blank() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Hyderabad");
	Thread.sleep(1000);
	factory.setState("Telangana");
	Thread.sleep(1000);
	factory.setCardname("srividya athota");
	Thread.sleep(1000);
	factory.setCardnumber("123456789");
	Thread.sleep(1000);
	factory.setCvv("1234");
	Thread.sleep(1000);
	factory.setMonth("");
	Thread.sleep(1000);
	factory.setButton();
}

@When("^user leaves expiration year blank$")
public void user_leaves_expiration_year_blank() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Hyderabad");
	Thread.sleep(1000);
	factory.setState("Telangana");
	Thread.sleep(1000);
	factory.setCardname("srividya athota");
	Thread.sleep(1000);
	factory.setCardnumber("123456789");
	Thread.sleep(1000);
	factory.setCvv("1234");
	Thread.sleep(1000);
	factory.setMonth("march");
	Thread.sleep(1000);
	factory.setYear("");
	Thread.sleep(1000);
	factory.setButton();
}

@When("^user enters valid details$")
public void user_enters_valid_details() throws Throwable {
	factory.setFname("vidya");
	Thread.sleep(1000);
	factory.setLname("Athota");
	Thread.sleep(1000);
	factory.setEmail("srividya@gmail.com");
	Thread.sleep(1000);
	factory.setMobile("8106792387");
	Thread.sleep(1000);
	factory.setAddress("chennai");
	Thread.sleep(1000);
	factory.setCity("Hyderabad");
	Thread.sleep(1000);
	factory.setState("Telangana");
	Thread.sleep(1000);
	factory.setCardname("srividya athota");
	Thread.sleep(1000);
	factory.setCardnumber("123456789");
	Thread.sleep(1000);
	factory.setCvv("1234");
	Thread.sleep(1000);
	factory.setMonth("march");
	Thread.sleep(1000);
	factory.setYear("2018");
	Thread.sleep(1000);
	factory.setButton();
}

@Then("^display success message$")
public void display_success_message() throws Throwable {
	
}	
	@After
	public void close() {
		driver.close();
	}

}
