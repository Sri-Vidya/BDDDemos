package com.cg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.CucumberOptions;

public class PageFactoryBooking {
WebDriver wd;
	
	
	public PageFactoryBooking(WebDriver webdriver) {
		this.wd=webdriver;
		PageFactory.initElements(wd, this);
		
	
	}
	public PageFactoryBooking() {
		
	}
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement fname;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lname;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(name="address")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(name="persons")
	@CacheLookup
	int persons;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement button;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardname;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement cardnumber;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement month;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement year;


	public WebElement getCardname() {
		return cardname;
	}
	public void setCardname(String cardname) {
		this.cardname.sendKeys(cardname);
	}
	public WebElement getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber.sendKeys(cardnumber);
	}
	public WebElement getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}
	public WebElement getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month.sendKeys(month);
	}
	public WebElement getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year.sendKeys(year);
	}
	public int getPersons() {
		return persons;
	}
	public void setPersons(int persons1) {
		persons = persons1;
	}
	public WebElement getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address.sendKeys(address);
	}
	public WebElement getCity() {
		return city;
	}
	public void setCity(String cityTemp) {
		Select city1=new Select(city);
		city1.selectByVisibleText(cityTemp);
	}
	public WebElement getState() {
		return state;
	}
	public void setState(String stateTemp) {
		Select state1 = new Select(state);
		state1.selectByVisibleText(stateTemp);
	}
	public WebElement getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}
	public WebElement getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}
	public WebElement getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}
	public WebElement getButton() {
		return button;
	}
	public void setButton() {
		button.click();;
	}

}
